# LocateFlow Design System

> Every provider tied to your address, in one place.

LocateFlow is a personal "address OS" — one dashboard per home that tracks every utility, bank, insurance, subscription, and service contract attached to that address. When you move, it becomes a one-click relocation checklist (transfer, cancel, reconnect) with state-specific rules for all 50 US states. The company calls itself a *moving companion* more than a sub-tracker — the moving flow is the headline feature, the sub/bill tracking is the substrate underneath.

## Surfaces

LocateFlow ships three surfaces, all in one Turborepo:

| Surface | Stack | Role |
|---|---|---|
| **Marketing + App (web)** | Next.js 14 App Router, shadcn/ui + Tailwind, Radix | Landing page, pricing, auth, in-app dashboard |
| **Mobile app** | Expo / React Native, NativeWind, lucide-react-native | Core product experience — addresses, services, moving plans, relocation checklist |
| **Admin** | Next.js 14, shadcn/ui + Tailwind | Internal admin console (same visual language as web) |

The mobile app is the **primary product experience** — it carries the darkest, highest-contrast variant of the brand. The web app mirrors the same tokens on a slightly more restrained surface. The admin console reuses the web kit with denser spacing.

## Index

Root files:

- `README.md` — this file
- `SKILL.md` — skill manifest for Claude Code / agent use
- `colors_and_type.css` — base CSS variables (colors, radii, spacing, shadow, type)
- `assets/` — logos, favicon, OG image, app icon (all Champagne & Rose)
- `preview/` — design-system preview cards (rendered in the Design System tab)
- `ui_kits/web/` — web UI kit (landing, auth, dashboard, moving, pricing)
- `ui_kits/mobile/` — mobile UI kit (tab bar, dashboard, service cards, moving day)
- `ui_kits/admin/` — admin UI kit (command palette, users, tickets, analytics)
- `showcase/` — earlier direction explorations (kept for reference only)
- `reference/codebase/` — imported source files used as the source of truth

Sources: `Msxlab/move-main` (GitHub). Full design context lives in the repo — import more files as needed, don't rebuild from screenshots.

---

## ⚠️ Active direction

This design system ships **one canonical direction: Champagne & Rose**. The product code in `reference/codebase/` still uses an earlier orange-on-near-black palette with Inter — **do not match the code**; match the files. When shipping back to the codebase, translate these tokens into the existing Tailwind scheme.

**Canonical palette (Edition VI · Champagne & Rose):**

| Role | Token | Hex |
|---|---|---|
| Primary accent (the pin, CTAs) | `--rose` | `#D4846A` |
| Hover / soft glows | `--rose-light` | `#EDB99D` |
| Pressed states | `--rose-deep` | `#A85A42` |
| Champagne foil highlight | `--foil-a` | `#F4E4D0` |
| Champagne foil body | `--foil-b` / `--foil` | `#E5C9A8` |
| Champagne foil shadow | `--foil-c` / `--nude-deep` | `#B8936C` |
| Sage (cool counterweight) | `--sage` | `#5EAD9A` |
| Umber canvas (dark default) | `--bg` | `#0E0A07` |
| Card | `--surface` | `#13100B` |
| Ivory paper (light mode) | `--bg` (light) | `#FBF7EC` |
| Foreground (dark) | `--fg` | `#F5F1EA` |

The **foil is a gradient**, not a flat color. Use `linear-gradient(135deg, var(--foil-a) 0%, var(--foil-b) 50%, var(--foil-c) 100%)` wherever the brand wants a moment — italic wordmarks, hero accents, CTA shine. Use the flat `--foil` only when a gradient won't render (SVG strokes, small chrome).

All previous directions (v1 orange / v2 terracotta) are **deprecated**. They survive in `showcase/` for reference only.

---

## Content fundamentals

**Voice.** Practical and reassuring, never breathless. Verbs over adjectives. Short lines, no emoji. The tone assumes the reader is mid-move, stressed, trying to cancel three things before a deadline — so every sentence gets to the point.

**Headline formula.** Three-beat phrases separated by periods, with the middle beat set in italic Fraunces and painted with the foil gradient:

> Every address. *Every service.* One place.

The italic-plus-foil treatment is the Champagne signature. It appears exactly once per view — hero headline, modal title, or section opener — never twice on the same page.

**Second-person.** Almost always "you"; never "we" except in FAQ replies ("Yes. You get…"). Possessives ground the product in the reader's life: *your address, your home, your service list*.

**Concrete category words.** "Utility, bank, insurance, streaming, gym, HOA." The copy never says "providers" in the abstract when it can list the real categories instead.

**Casing.** Sentence case in body; Title Case on H1/H2/section headers ("How It Works", "Loved by Movers Everywhere"). Button labels: Title Case ("Start Free Trial", "Open Dashboard").

**Trust markers, not hype.** "No credit card required", "Cancel anytime", "Your data stays available for 30 days after cancellation", "GDPR / CCPA compliant". Specific, verifiable, humble.

**Light playfulness, reserved.** "Made with care for movers everywhere" in the footer. FAQ answers are warm but not cute ("Yes. You get ${TRIAL_DURATION_DAYS} days free with no credit card required.").

**Avoid.** Emoji in UI copy. Exclamation marks. Gen-Z phrasing. "Magic", "AI-powered", "unlock", "game-changer". The product is deliberately adult and boring-in-a-good-way.

---

## Visual foundations

### Palette — Champagne & Rose on umber

The brand rests on **two accents** (Rose `#D4846A` for UI action, Champagne Foil for brand moments) against a warm near-black canvas. Sage `#5EAD9A` is the one cool counterweight and appears sparingly — success states, sparingly tinted category chips.

- **Primary action** `--rose #D4846A`. The pin color. CTAs, focus rings, primary buttons, active nav indicator.
- **Hover glow** `--rose-light #EDB99D`. Soft glows, subtle highlights, illustration fills.
- **Brand moment** Foil gradient (`--foil-a → --foil-b → --foil-c`). Italic wordmarks, hero eyebrows, wax seal, hairline chrome.
- **Canvas (dark)** `--bg #0E0A07`. Umber-near-black, slightly warm. Slightly lighter than pure black so the foil can breathe.
- **Card** `--surface #13100B`. Subtle elevation, never pure white-on-dark.
- **Borders** are always alpha, never opaque: `rgba(245,241,234,0.08)` default, `0.14` hover. A dedicated `--line-foil` (22% alpha foil-b) powers the hairline double-border on luxury chrome.

**Light mode** inverts surfaces to ivory paper (`--bg #FBF7EC`) and deepens the rose a hair (`#B85A42`) for contrast. The foil ink becomes `--foil-ink #8E6D4A` for text-on-paper use. The product still *ships* dark — light mode is a courtesy.

**Tonal category pairs.** Every "tone" (rose, foil, sage, honey, umber, slate) ships as a `{bg, border, fg}` triplet — `--tone-*-bg` at ~9% alpha, `--tone-*-br` at ~22% alpha, `--tone-*-fg` bright on dark. This is the language of stat cards, category chips, service-type indicators. Do not invent new tones — pick from the six.

### Type

**Fraunces** for display (variable: `opsz 9..144`, `SOFT 0..100`, italic available). **Geist** for sans UI. **Geist Mono** for numerals, meta, kickers, and code. Inter is the fallback, not the default.

Fraunces carries the brand's personality through **italic + opsz + SOFT**. Hero headlines use `opsz 144 / SOFT 50` for maximum warmth. Smaller display sizes step down to `opsz 96 / SOFT 40`, `opsz 48 / SOFT 30`. The italic `flow` in the wordmark is always foil-gradient-filled.

Scale (tokens in `colors_and_type.css`):

| Token | Size | Use |
|---|---|---|
| `--fs-display-xl` | 96px | Marketing hero |
| `--fs-display-lg` | 72px | Section hero on landing |
| `--fs-display` | 48px | Major section titles |
| `--fs-4xl` | 36px | Page h1 in-app |
| `--fs-3xl` | 28px | Dashboard h1, stat values |
| `--fs-2xl` | 22px | Card titles |
| `--fs-xl` | 18px | Lede, section headings |
| `--fs-lg` | 16px | Body lead |
| `--fs-base` | 14px | Default body, buttons |
| `--fs-sm` | 12px | Labels, stat labels, meta |
| `--fs-xs` | 11px | Captions, kbd hints, kickers |

Weights in use: Fraunces 300 / 400 / 500 (italic at 300 and 400). Geist 300 / 400 / 500 / 600 / 700. Geist Mono 400 / 500 / 600.

### Backgrounds

Almost every hero or card sits on the umber canvas. Where the old direction used orange glow blobs, this direction uses **soft foil washes** — a 24–40px-blurred rectangle of `--foil-b` at 6–10% opacity behind hero content, or a radial glow anchored in the top-right corner. Glass overlays (`--glass-bg`, `backdrop-filter: blur(24px)`) sit over these washes to bring content forward.

No photographs, no stock imagery. Brand "imagery" is **type + geometry + foil** — the logo mark, the wordmark italic flourish, the wax seal on letters.

### Cards

- Rounded `--radius-md 10px` default; `--radius-lg 14px` on marketing; `--radius-xl 20px` on pricing and hero stages.
- Border `1px solid var(--line)` on dark.
- Background: `--surface #13100B`. Never pure black.
- Shadow: `--shadow-sm` at rest; `--shadow-md` + slight translate on hover for marketing feature cards.
- Glass cards (landing, modals): `.glass` helper — `backdrop-filter: blur(24px)` + `--glass-bg` + `--glass-border`.
- **Hairline chrome**: `.hairline` helper adds a foil-colored inner border inset 14px. Use on hero stages and premium surfaces only.

### Buttons

Five variants: `primary` (rose solid), `secondary` (foil outline on cream fill), `outline` (line-2 on transparent), `ghost`, `destructive`. Sizes `sm / default / lg / icon` at heights `36 / 40 / 44 / 40px`. Rounded `--radius-md` (10px). **Hover = 90% rose on primary**, `--glass-hover` on ghost/outline. Focus is `--border-focus` rose at 55% alpha, 2px outline.

A sixth variant exists: `foil` — a gradient fill that runs `--foil-a → --foil-b → --foil-c`, ink text (`#1A1713`), and `--shadow-foil` glow. Reserve it for premium moments: upgrade CTAs, "Order your moving pack", Stripe success.

### Animations

- Easing is default ease-out on everything.
- Durations: `200ms` transitions on cards, buttons, theme toggle. Accordions 200ms.
- A slow, 3-second shimmer sweep across the foil gradient on hover of primary-foil CTAs (`background-size: 200% 100%` + `background-position: 0% → 100%`).
- Pulse on "coming soon" status dots.
- No bouncy springs. No parallax.

### Hover & press

- **Hover (dark)**: bg lightens to `--glass-hover` (7% alpha fg), text shifts to `--fg`, border stays.
- **Focus**: `--border-focus` rose 2px outline at 55% alpha.
- **Mobile press**: `activeOpacity={0.7}` (native). Full-width foil buttons get `--shadow-foil`.
- **Disabled**: `opacity-50 pointer-events-none`.

### Shadows

- `--shadow-xs` through `--shadow-xl` for default elevation.
- `--shadow-rose` (rose glow at 28% alpha, 20px blur) is reserved for the primary CTA's active state — don't spray it on normal cards.
- `--shadow-foil` (foil glow at 16% alpha, 30px blur) is reserved for premium/upgrade moments.

### Transparency & blur

**Glass** appears on sticky headers (`--glass-bg` + `backdrop-filter: blur(24px)`), modals, and overlays. Blur values are always `24px` or `40px`, never less. The dashboard itself is mostly solid surfaces for scannability — glass is the exception, not the rule.

### Layout rules

- Web container: centered, `2rem` padding, max `1280px`.
- Landing sections alternate plain container with `--surface-2` bands for rhythm. Section separators are always `1px solid var(--line)` — never a heavy divider.
- Dashboard sidebar: fixed, dark (`--surface`) even in light mode.
- Mobile tabs: bottom bar, 5 tabs (Home, Addresses, Services, Moving, More), each 44–48px hit target with lucide icon + label.

### Imagery vibe

**Type, geometry, and foil — no photos.** Brand "imagery" is:
- The logo mark — foil arc from origin dot to rose pin (`assets/logo-mark.svg`).
- The italic foil wordmark — Fraunces italic, foil gradient-filled, in the word "flow".
- The wax seal — a rose-deep circle with the LF monogram in foil, used on letters and PDF exports.
- Hairline chrome — foil-colored inner borders on hero stages.

If you need imagery, use a placeholder block with the foil gradient at 8% opacity — not AI stock scenes.

---

## Iconography

**Lucide** is the only icon library used. Both web (`lucide-react`) and mobile (`lucide-react-native`) pull from the same set — matching stroke weight (1.75px for this direction, a hair thinner than Lucide's default 2px to sit well with Fraunces light), matching geometry. Icon sizes are usually `14 / 16 / 18 / 20 / 22 / 24` px. Icons inherit `currentColor` from their container — never hardcode hex on an icon except on the rose pin in brand moments.

Commonly used icons:

- **Core product**: `MapPin` (addresses), `Zap` (services), `Truck` (moving), `Bell` (reminders), `DollarSign` (budget), `FileText` (documents), `CheckSquare` / `CheckCircle2` (tasks), `Shield` (security/trust).
- **Dashboard/UI**: `ArrowRight`, `ChevronDown`, `TrendingUp`, `Trophy`, `Star`, `Clock`, `AlertTriangle`, `Quote`.
- **No emoji.** The brand sets its tone through Fraunces italic and foil — emoji would undercut it.

**SVG assets** in `assets/` (all redrawn in Champagne & Rose):

- `logo.svg` — horizontal wordmark + mark, foil italic "flow"
- `logo-mark.svg` — mark only (foil arc, rose pin)
- `favicon.svg` — mark on umber square
- `app-icon.svg` — mobile app tile, full-bleed umber + foil + rose
- `og-image.svg` — social share card

No icon font. No sprite sheet. Use lucide via CDN in prototypes:

```html
<script type="module">
  import { createIcons, icons } from "https://unpkg.com/lucide@latest/dist/esm/lucide.js";
  createIcons({ icons, attrs: { 'stroke-width': 1.75 } });
</script>
<i data-lucide="map-pin"></i>
```

**Font note.** Fraunces and Geist are loaded from Google Fonts at runtime (see `colors_and_type.css`). Fraunces is used as a variable font — `opsz` and `SOFT` axes matter. If you need offline fonts, pull the variable TTFs from Google Fonts.
