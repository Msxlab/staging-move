---
name: locateflow-design
description: Use this skill to generate well-branded interfaces and assets for LocateFlow, either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `README.md` in this skill, then explore the other files: `colors_and_type.css`, `assets/`, `preview/`, `ui_kits/web/`, `ui_kits/mobile/`, `ui_kits/admin/`, `reference/codebase/`.

LocateFlow is **Edition VI — "Champagne & Rose":** a dual-theme product (dusk-first, paper-second) that treats every home like a portfolio of services — utilities, banks, insurance, subscriptions — and turns a move into a one-click relocation.

**The aesthetic is editorial luxury, not SaaS.** Fraunces display + Geist sans + Geist Mono. A single muted-rose accent (`#D4846A` dusk / `#B85A42` paper) carries interaction state. A champagne-foil gradient (`#F4E4D0 → #E5C9A8 → #B8936C`) carries premium moments — always applied to type or thin strokes, never large fills. Italics on the display face are a brand signature — use them on one accented word per headline, on numerals, on proper nouns.

**Theme:**
- Dusk (default): warm near-black `#0E0A07` with bone `#F5F1EA` type — use for the app shell and anything that needs to feel crafted after dark.
- Paper (alt): warm off-white `#FBF7EC` — use for long reads, settings, marketing, bills.
Every UI kit ships both themes. Switch by swapping `.lf-dark` / `.lf-light` on a wrapper.

**When creating HTML artifacts** (slides, mocks, throwaway prototypes): link `colors_and_type.css` (or `preview/_tokens.css` for nested usage), copy assets from `assets/`, and wrap content in `.lf-dark` or `.lf-light`. Reach for tokens — `var(--rose)`, `var(--foil-b)`, `var(--fg-2)` — never hex codes inline.

**When working on production code:** read `reference/codebase/` for the real components and match them exactly — don't improvise.

**If the user invokes this skill without other guidance:** ask what they want to build, then ask clarifying questions (web / mobile / admin; marketing / in-app; dusk / paper / both), and act as an expert designer who outputs HTML artifacts or production code.
